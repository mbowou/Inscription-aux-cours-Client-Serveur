import java.io.IOException;
import java.util.Objects;
import java.util.Scanner;
import java.util.Vector;

public class ClientLauncher {
    private static Scanner scanner = new Scanner(System.in);
    private static String Choix = "0";
    private static Client client;
    public static void main(String[] args) {
        try {
            System.out.println("Vous êtes connecté au Serveur...");
            client = new Client();

        } catch (Exception e) {
            e.printStackTrace();
        }

        Menu();
    }

    public static void Menu()
    {
        Choix = "0";

        System.out.println(".________________________________________________________________________________________.");
        System.out.println("|****              Bienvenu au portail d'inscription de cours de l'UDEM              ****|");
        System.out.println("|                                                                                        |");
        System.out.println("| -Veuillez choisir la session pour laquelle vous voulez consulter a liste des cours     |");
        System.out.println("|                                                                                        |");
        System.out.println("| 1. Automne                                                                             |");
        System.out.println("| 2. Hiver                                                                               |");
        System.out.println("| 3. Ete                                                                                 |");
        System.out.println("|________________________________________________________________________________________|");
        while (!Choix.equals("1") && !Choix.equals("2") && !Choix.equals("3"))
        {
            Choix(3);
        }

        ChoixCours(Choix);
    }

    public static void ChoixCours(String Session)
    {
        Choix = "0";

        String S = "";
        Vector<String> listeCours = new Vector<>();
        System.out.println(".________________________________________________________________________________________.");
        System.out.println("|                                                                                        |");

        if(Session.equals("1"))
        {
            System.out.println("| -Les cours offerts pendant la session d'Automne sont :                                 |");
            S = "Automne";
        }
        else if(Session.equals("2"))
        {
            System.out.println("| -Les cours offerts pendant la session d'Hiver sont :                                   |");
            S = "Hiver";
        }
        else if(Session.equals("3"))
        {
            System.out.println("| -Les cours offerts pendant la session d'Ete sont :                                     |");
            S = "Ete";
        }
        listeCours = client.F1(S);
        for (int i = 0; i < listeCours.size(); i++)
        {
            System.out.println("| "+ (i+1) +". "+ listeCours.get(i));
        }
        System.out.println("._______________________________________________________________________________________.|");
        System.out.println("| 1. Changer de session                                                                  |");
        System.out.println("| 2. S'inscrire à un cours                                                               |");
        System.out.println("|________________________________________________________________________________________|");
        while (!Choix.equals("1") && !Choix.equals("2"))
        {
            Choix(2);
        }

        if(Choix.equals("2"))
        {
            Inscription(S, listeCours);
        }
        else {
            Menu();
        }
    }

    public static void Inscription(String Session, Vector<String> Cours)
    {
        System.out.println(".________________________________________________________________________________________.");
        System.out.println("|*****                                 Inscription                                  *****|");
        System.out.println("|                                                                                        |");
        System.out.print("| - Veuillez saisir votre prénom    : ");
        String Prenom = scanner.nextLine();

        System.out.print("| - Veuillez saisir votre Nom       : ");
        String Nom = scanner.nextLine();

        System.out.print("| - Veuillez saisir votre email     : ");
        String Email = scanner.nextLine();

        System.out.print("| - Veuillez saisir votre matricule : ");
        String Matricule = scanner.nextLine();

        System.out.print("| - Veuillez saisir le code du cour : ");
        String CodeCours = scanner.nextLine();

        //Pour verifier si le code du cours est correcte
        for (int i = 0; i < Cours.size(); i++)
        {
            String code = Cours.get(i).toString().split("\t")[1];
            if(code.equals(CodeCours))
            {
                System.out.println(".________________________________________________________________________________________.");
                System.out.println("|                    "+ client.F2(Session, CodeCours, Matricule, Prenom, Nom, Email) +"                     |");
                System.out.println("|________________________________________________________________________________________|");
                Menu();
            }
        }
        System.out.println(".________________________________________________________________________________________.");
        System.out.println("|                   Aucun Cours de correspond aux informations entrées                   |");
        System.out.println("|________________________________________________________________________________________|");
        Menu();
    }

    public static void Choix(int limit)
    {
        Choix = "0";
        System.out.print  ("|> Choix : ");
        Choix = scanner.nextLine();

        if(limit == 3)
        {
            if (!Choix.equals("1") && !Choix.equals("2") && !Choix.equals("3"))
            {
                System.out.println("| -Erreur : Ce choix n'est pas disponible...");
            }
        }
        else if (limit == 2)
        {
            if (!Choix.equals("1") && !Choix.equals("2"))
            {
                System.out.println("| -Erreur : Ce choix n'est pas disponible...");
            }
        }

    }
}