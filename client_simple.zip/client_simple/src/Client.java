import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Collection;
import java.util.Objects;
import java.util.Vector;


/**
 * @author
 *
 *
 */
public class Client {

    public final static String REGISTER_COMMAND = "INSCRIRE";
    public final static String LOAD_COMMAND = "CHARGER";
    private Socket serveur;
    private ObjectInputStream objectInputStream;
    private ObjectOutputStream objectOutputStream;

    public Client() {

    }

    public void Connexion() throws IOException {
        serveur = new Socket("localhost", 1337);
        objectOutputStream = new ObjectOutputStream(serveur.getOutputStream());
        objectInputStream = new ObjectInputStream(serveur.getInputStream());
    }

    public Vector<String> F1(String Session)
    {
        try {
            Connexion();
        } catch (IOException e) {
            System.out.println("Connexion au serveur impossible");
        }

        try {
            //Envoie de la commande pour recevoir la liste des cours
            objectOutputStream.writeObject(LOAD_COMMAND + " "+ Session);

            try {
                //Reception de la liste des cours
                return (Vector<String>) objectInputStream.readObject();

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String F2(String Session, String CodeCours, String Matricule, String Prenom, String Nom, String Email)
    {
        try {
            Connexion();
        } catch (IOException e) {
            System.out.println("Connexion au serveur impossible");
        }

        String [] objects = new String[]{Session, CodeCours, Matricule, Prenom, Nom, Email};
        try {
            //Envoie de la commande pour pour l'inscription
            objectOutputStream.writeObject(REGISTER_COMMAND + " ");

            //Envoie des données d'inscription
            objectOutputStream.writeObject(objects);

            try {
                //Reception de la Notification
                Object[] objects1 = (Object[]) objectInputStream.readObject();
                return objects1[0].toString();

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
