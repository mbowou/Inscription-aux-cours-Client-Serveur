package server;

/**
 * Classe principale du programme
 */
public class ServerLauncher {
    /**
     * le numéro de port avec lequel serveur ouvre un accès pour reçevoir toutes les requêtes
     */
    public final static int PORT = 1337;

    /**
     * fonctions principale du programme qui crée une instance de serveur,
     * puis le démarre
     * @param args arguments d'entrées de la fonction principale
     */

    public static void main(String[] args) {
        Server server;

        try {
            server = new Server(PORT);
            System.out.println("Server is running...");


            new Thread(new Runnable() {
                @Override
                public void run() {
                    server.run();
                }
            }).start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}