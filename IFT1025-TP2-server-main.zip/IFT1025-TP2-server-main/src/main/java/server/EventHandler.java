package server;

/**
 * interface fonctionnelle qui n'implémente qu'une seule méthode
 */
@FunctionalInterface
public interface EventHandler {

    /**
     * cette fonction est une
     * @param cmd
     * @param arg
     */
    void handle(String cmd, String arg);
}
