package server;

import javafx.util.Pair;
import server.models.Course;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URISyntaxException;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * Server est une classe qui permet de lancer un serveur
 * qui repondra aux requêtes des différents clients
 *
 */

public class Server {
    /**
     * commande qui signifi qu'un client souhaite s'inscrire
     */
    public final static String REGISTER_COMMAND = "INSCRIRE";

    /**
     * commande qui signifi qu'un client souhaite obtenir la liste des cours
     */
    public final static String LOAD_COMMAND = "CHARGER";

    /**
     * contient la connexion établie par le serveur
     */
    private final ServerSocket server;

    /**
     * contient chaque nouvelle connexion de client
     */
    private Socket client;

    /**
     * flux permettant de recevoire les requêtes clients
     */
    private ObjectInputStream objectInputStream;

    /**
     * flux permettant d'envoyer des réponses aux clients
     */
    private ObjectOutputStream objectOutputStream;

    /**
     * liste d'interface permettant d'envoyer les réponses aux clients
     */
    private final ArrayList<EventHandler> handlers;

    /**
     * la méthode Server est le constructeur qui permet d'instancier un serveur
     * il utilise le numéro de port pour initialiser le socket
     * et on implemente la méthode handle de l'interface 'EventHandle' avec la méthode 'handleEvents'
     * @param port le numéro de port par lequel les clients pourrons échanger avec le serveur
     * @throws IOException capture tous les problèmes liés à la creation d'un socket de serveur
     */
    public Server(int port) throws IOException {
        this.server = new ServerSocket(port, 1);
        this.handlers = new ArrayList<EventHandler>();
        this.addEventHandler(this::handleEvents);
    }

    /**
     * ajouter une interface à la liste d'interface
     * @param h représente l'interface qui sera ajouté à la liste
     */
    public void addEventHandler(EventHandler h) {
        this.handlers.add(h);
    }

    /**
     * parcours lance la méthode handle pour chaque interface de la liste d'interface
     * @param cmd représente la commande envoyée par le client
     * @param arg il s'agit de la session dont l'utilisateur veut récupérer la liste des cours
     */
    private void alertHandlers(String cmd, String arg) {
        for (EventHandler h : this.handlers) {
            h.handle(cmd, arg);
        }
    }

    /**
     *run est la méthode détecte une connexion d'un utilisateur
     * et maintient le serveur allumé pour tout client
     * elle initialise ensuite les flux d'entré et de sortie des objets
     * puis attend la  requête du client qui se connecte
     * et le déconnecte par la suite
     */
    public void run() {
        while (true) {
            try {
                client = server.accept();
                System.out.println("Connecté au client: " + client);
                objectInputStream = new ObjectInputStream(client.getInputStream());
                objectOutputStream = new ObjectOutputStream(client.getOutputStream());

                //pour servir plusieurs clients, on duplique l'instance du serveur actuel;
                Server server1 = this;

                //on démarre un thread qui se charge de servir le client actuel avec l'instance du serveur que nous avons dupliqué
                //ce qui libère le serveur principale afin qu'il puisse accepter de nouveaux clients.

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            server1.listen();
                            server1.disconnect();
                            System.out.println("Client déconnecté!");
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }).start();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * listen est la méthode qui attend une requête du client ensuite
     * elle traite la requete pour savoir ce que veut le client
     * puis lance la méthode alertHanglers
     * @throws IOException cette exception capture tous les problemes qui suviennent lorsqu'on essaie de réceptionner une requête client
     * @throws ClassNotFoundException permet de s'assurer que la commande envoyée par le client est compatible au type de commande attendue
     */
    public void listen() throws IOException, ClassNotFoundException {
        String line;
        if ((line = objectInputStream.readObject().toString()) != null) {
            Pair<String, String> parts = processCommandLine(line);
            String cmd = parts.getKey();
            String arg = parts.getValue();
            this.alertHandlers(cmd, arg);
        }
    }

    /**
     * subdivise la requête en deux en utilisant l'espace qu'elle contient
     * la première partie représente la commande et la seconde est l'argument de la requête
     * @param line la requête envoyée par le client
     * @return la commande ainsi les arguments necessaires pour exécuter la commande à savoir la session
     */
    public Pair<String, String> processCommandLine(String line) {
        String[] parts = line.split(" ");
        String cmd = parts[0];
        String args = String.join(" ", Arrays.asList(parts).subList(1, parts.length));
        return new Pair<>(cmd, args);
    }

    /**
     * ferme le flux de sortie avec la méthode 'close' de la classe 'ObjectOutputStream',
     * ferme le flux d'entrée avec la méthode 'close' de la classe 'ObjectinputStream',
     * ferme la connexion au client (socket),
     *
     * @throws IOException capture tous les problèmes liés à la fermeture des différents flux et du socket
     */
    public void disconnect() throws IOException {
        objectOutputStream.close();
        objectInputStream.close();
        client.close();
    }


    /**
     * test si la commande correspond à un enregistrement ou s'il s'agit d'une demande de liste des cours
     * s'il s'agit d'une inscription à un cours on appel la méthode handleRegistration sans paramètre
     * s'il s'agit d'une demande de liste des cours d'une session on lance la méthode correspondate avec en paramètre la session souhaitée
     * @param cmd c'est l'action que souhaite effectuée l'utilisstauer
     * @param arg c'est la session précisée par l'utilisateur dans le cas d'une demande de liste des cours
     */
    public void handleEvents(String cmd, String arg) {
        if (cmd.equals(REGISTER_COMMAND)) {
            handleRegistration();
        } else if (cmd.equals(LOAD_COMMAND)) {
            handleLoadCourses(arg);
        }
    }

    /**
     Lire un fichier texte contenant des informations sur les cours et les transofmer en liste d'objets 'Course'.
     La méthode filtre les cours par la session spécifiée en argument.
     Ensuite, elle renvoie la liste des cours pour une session au client en utilisant l'objet 'objectOutputStream'.
     La méthode gère les exceptions si une erreur se produit lors de la lecture du fichier ou de l'écriture de l'objet dans le flux.
     @param arg la session pour laquelle on veut récupérer la liste des cours
     */
    public void handleLoadCourses(String arg) {

        //Ouverture du fichier

        File Cours = null;
        try {
            Cours = new File(Server.class.getClassLoader().getResource("cours.txt").toURI());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        Vector<String> courses = new Vector<>();

        //Vérification de l'existance du fichier
        if(Cours.exists())
        {
            try {
                //Tantative de lecture du fichier
                Scanner Lecteur = new Scanner(Cours);
                String Ligne ;

                //Lecture du fichier ligne par ligne
                while (Lecteur.hasNextLine())
                {
                    Ligne = Lecteur.nextLine();

                    //On filtre les cours pour une Session spécifique
                    if(Ligne.split("\t")[2].equals(arg))
                    {
                        courses.add(Ligne.split("\t")[1] + "\t" + Ligne.split("\t")[0]);
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("Fichier introuvable...");
            }
        }
        else {
            System.out.println("Le fichier spécifié n'existe pas");
        }

        //Envoie de la liste des cours au client
        try {
                objectOutputStream.writeObject(courses);
        }
        catch (IOException e) {
            System.out.println("Un probleme est survenu...");
        }
    }

    /**
     Récupérer l'objet 'RegistrationForm' envoyé par le client en utilisant 'objectInputStream', l'enregistrer dans un fichier texte
     et renvoyer un message de confirmation au client.
     La méthode gére les exceptions si une erreur se produit lors de la lecture de l'objet, l'écriture dans un fichier ou dans le flux de sortie.
     */
    public void handleRegistration() {


        try {
            File file = new File("inscription.txt");
            if(!file.exists())
            {
                file.createNewFile();
            }
        } catch (IOException e) {
            try {
                objectOutputStream.writeObject(new Object[]{"Désolé !\n" +
                        "Une erreur est survenue lors de votre inscription", false});
            } catch (IOException ex) {
                System.out.println("Une erreur est survenue");
            }
            return;
        }

        String[] RegistrationForm = null;
        //Récupération de l'objet RegistrationForm du client
        try {
            RegistrationForm = (String []) objectInputStream.readObject();

            //Vérifion si l'étudiant s'est déja inscrit a un cours

            if(EtudiantExistant(RegistrationForm[2]))
            {
                objectOutputStream.writeObject(new Object[]{"Désolé !\n" +
                        "Il semble que vous soyez déja inscrit à un de nos cours", false});
                return;
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Un probleme est survenu...");
        }

        //Ouverture du fichier d'inscrition pour écriture
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter("inscription.txt", true);

            BufferedWriter br = new BufferedWriter(fileWriter);

            //On formate les données pour écriture dans le fichier
            String Donnees  = String.join("\t", (String[]) RegistrationForm)+"\n";
            br.write(Donnees);

            //Fermeture du fichier(sauvegarde)
            br.close();
            fileWriter.close();
        } catch (IOException e) {
            System.out.println(e);
            try {
                //Envoie de la notification au client
                objectOutputStream.writeObject(new Object[]{"Une erreur est Survenue Lors de votre inscription", false});
            } catch (IOException ex) {
                System.out.println("Un probleme est survenu...");
            }
        }


        try {
            //Envoie de la notification au client
            objectOutputStream.writeObject(new Object[]{"Féliciation votre inscription a été enregistrée", true});
        } catch (IOException e) {
            System.out.println("Un probleme est survenu...");
        }
    }

    /**
     * cette méthode lis ligne par ligne dans le fichier contenant la liste des inscriptions
     * pour chaque ligne elle vérifi si le matricule de l'étudiant qui sounaite s'enregistré existe déjà
     * si une ligne contient le matricule d'un étudiant on retourne 'true'
     * sinon on retourne 'false'
     * @param Matricule le matricule de l'étudiant qui sounaite s'enregistrer
     * @return retoune true si l'étudiant à déjà été enregistré pour un cour et false dans le cas contraire
     */
    public boolean EtudiantExistant(String Matricule)
    {
        //Ouverture du fichier
        File Inscription = new File("src\\main\\java\\server\\data\\inscription.txt");

        //Vérification de l'existance du fichier
        if(Inscription.exists())
        {
            try {
                //Tantative de lecture du fichier
                Scanner Lecteur = new Scanner(Inscription);
                String Ligne ;

                //Lecture du fichier ligne par ligne
                while (Lecteur.hasNextLine())
                {
                    Ligne = Lecteur.nextLine();
                    //On vérifie si l'étudiant s'est déjà inscrit à un cours
                    if(Ligne.contains(Matricule))
                    {
                        return true;
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("Fichier introuvable...");
            }
        }
        else {
            System.out.println("Le fichier spécifié n'existe pas");
        }
        return false;
    }
}

